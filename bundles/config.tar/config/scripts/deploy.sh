#!/bin/bash

sudo sh -c "echo 'sysadmin ALL=(ALL) NOPASSWD: /opt/tretflix/.sys/cli/TretflixCLI.sh' >> /etc/sudoers"

sudo mkdir /media/disk2/downloads
sudo chown sysadmin:sysadmin /media/disk2/downloads
mkdir /media/disk2/downloads/Movies
mkdir /media/disk2/downloads/Music
mkdir /media/disk2/downloads/Other
mkdir /media/disk2/downloads/TV

sudo mkdir /media/disk2/tmp
sudo chown sysadmin:sysadmin /media/disk2/tmp
mkdir /media/disk2/tmp/plexmediaserver
mkdir /media/disk2/tmp/plexmediaserver/transcodes
mkdir /media/disk2/tmp/sabnzbdplus
mkdir /media/disk2/tmp/sabnzbdplus/incomplete
mkdir /media/disk2/tmp/sabnzbdplus/couchpotato
mkdir /media/disk2/tmp/sabnzbdplus/headphones
mkdir /media/disk2/tmp/sabnzbdplus/nzbdrone
mkdir /media/disk2/tmp/sabnzbdplus/sickbeard
mkdir /media/disk2/tmp/transmission-daemon
mkdir /media/disk2/tmp/transmission-daemon/incomplete

sudo mkdir /mnt/.test

cp -f /opt/tretflix/.sys/config/home/bash_aliases /home/sysadmin/.bash_aliases
cp -f /opt/tretflix/.sys/config/home/profile /home/sysadmin/.profile

mkdir /home/sysadmin/.config
ln -s /opt/tretflix/appdata/nzbdrone/ /home/sysadmin/.config/NzbDrone

sudo cp -f /opt/tretflix/.sys/config/apache2/proxiedhosts /etc/apache2/sites-available/proxiedhosts
sudo ln -s /etc/apache2/sites-available/proxiedhosts /etc/apache2/sites-enabled/proxiedhosts

sudo cp -f /opt/tretflix/.sys/config/default/couchpotato /etc/default/couchpotato
sudo cp -f /opt/tretflix/.sys/config/default/headphones /etc/default/headphones
sudo cp -f /opt/tretflix/.sys/config/default/plexmediaserver /etc/default/plexmediaserver
sudo cp -f /opt/tretflix/.sys/config/default/sabnzbdplus /etc/default/sabnzbdplus
sudo cp -f /opt/tretflix/.sys/config/default/sickbeard /etc/default/sickbeard
sudo cp -f /opt/tretflix/.sys/config/default/transmission-daemon /etc/default/transmission-daemon

sudo cp -f /opt/tretflix/.sys/config/init/nzbdrone.conf /etc/init/nzbdrone.conf
sudo cp -f /opt/tretflix/.sys/config/init/nzbdrone.override /etc/init/nzbdrone.override
sudo cp -f /opt/tretflix/.sys/config/init/plexmediaserver.conf /etc/init/plexmediaserver.conf
sudo cp -f /opt/tretflix/.sys/config/init/plexmediaserver.override /etc/init/plexmediaserver.override

sudo cp -f /opt/tretflix/.sys/config/init.d/couchpotato /etc/init.d/couchpotato
sudo cp -f /opt/tretflix/.sys/config/init.d/headphones /etc/init.d/headphones
sudo cp -f /opt/tretflix/.sys/config/init.d/sabnzbdplus /etc/init.d/sabnzbdplus
sudo cp -f /opt/tretflix/.sys/config/init.d/sickbeard /etc/init.d/sickbeard
sudo cp -f /opt/tretflix/.sys/config/init.d/transmission-daemon /etc/init.d/transmission-daemon

sudo cp -f /opt/tretflix/.sys/config/samba/smb.conf /etc/samba/smb.conf
